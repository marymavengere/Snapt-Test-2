<template>
    <div>
        <label>{{ label }}</label>
        <input type="text" v-model="text" v-on:keyup="sendData()"> 
        <input v-model="checkbox" v-on:keyup="sendData()"> 
    </div>
</template>
<script>
module.exports = {
    props: ["value", "label-prop"],
    data() {
        return{
            text: this.value,
            label: this.labelProp
        };
    },
   
}
</script>