<template>
  <div class="topbar">
    <div v-if="showLogo">
      <span>
        <img src="/img/svg/Snapt_logo.png"/>
        {{ siteTitle }}
      </span>
    </div>
    <div class="tools">
      <div>
        
      </div>
      <div>
        <span><p>AA</p></span>
      </div>
    </div>
  </div>
</template>
<script>
module.exports = {
  props: ['show-logo', 'site-title'],
  data() {
    return {
      messageCounter: 0
    };
  },
  created() {
    let self = this
    setTimeout(function() {
      self.messageCounter = 2;
    }, 3000);
  }
}
</script>