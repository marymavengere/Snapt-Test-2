<template>
  <div class="scroll-to-top" v-on:click="scrollToTop()"><img src="/img/svg/arrow_white.svg"/></div>
</template>
<script>
module.exports = {
  methods: {
    scrollToTop() {
      window.scrollTo({
          top: 0,
          left: 0,
          behavior: 'smooth'
      })
    }
  }
}
</script>