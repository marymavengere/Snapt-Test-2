<template>
  <div :class="collapsed ? 'nav-container-collapsed' : 'nav-container'">
    <div>
      <span>
        <img v-if="!collapsed" src="/img/svg/Snapt_logo.png"/>
        {{ collapsed ? '' : siteTitle }}
        <img :src="collapsed ? '/img/svg/menu.svg' : '/img/svg/close.svg'" @click="toggleCollapsed(!collapsed, $event)"/>
      </span>
    </div>
    <div v-for="(linkCategory, mainCategoryIndex) in linkCategories" v-bind:key="mainCategoryIndex" :class="linkCategory.visible ? 'active' : ''" v-on:mouseleave="collapsed ? removeAllVisibility() : ''">
      <div v-on:click="toggleLinkCategory(mainCategoryIndex)" v-on:mouseenter="collapsed ? toggleLinkCategory(mainCategoryIndex) : ''" v-on:mouseleave="collapsed ? removeHover() : ''">
        <img :src="'/img/svg/' + linkCategory.icon + linkCategory.iconState + '.svg'"/>
        {{ collapsed ? '' : linkCategory.categoryTitle }}
        <img v-if="!collapsed" src="/img/svg/chevron_down.svg"/>
      </div>
      <span v-on:mouseenter="collapsed ? isHoveringSide = true : ''" v-on:mouseleave="collapsed ? exitHover() : ''" v-if="linkCategory.visible">
        <div v-if="collapsed">{{ linkCategory.categoryTitle }}</div>
          <a
            v-for="(link, subCategoryIndex) in linkCategory.links" v-bind:key="subCategoryIndex"
            v-show="link.isSubCategory ? subCategorySelected == link.linkGroup ? true : false : true"
            :href="link.to"
            :class="link.isIndented ? link.to == subCategoryLinkSelected ? 'nested-active' : 'nested': link.linkGroup == subCategorySelected ? 'active' : ''"
            v-on:click="toggleSubCategory(link.linkGroup)"
          >{{ link.linkTitle }}
          </a>
      </span>
    </div>
  </div>
</template>

<script>
module.exports = {
  props: ['site-title'],
  data() {
    return {
      collapsed: false,
      isHoveringSide: false,
      subCategorySelected: null,
      subCategoryLinkSelected: null,
      linkCategories: [
        { categoryTitle: "Load Balancer", icon: "admin", iconState: "_filled", visible: true, links: [
          { linkTitle: "AWS EC2", to: "/loadBalancer/AWS-EC2.html", isSubCategory: false, linkGroup: 0, isIndented: false },
          { linkTitle: "Digital Ocean", to: "/loadBalancer/Digital-Ocean.html", isSubCategory: false, linkGroup: 1, isIndented: false },
          // EXAMPLE OF A NESTED NAVIGATION ITEM
        
        ]},
        
      ]
    };
  },
  created() {
    for(var linkCategoriesIndex = 0; linkCategoriesIndex < this.linkCategories.length; linkCategoriesIndex++){
      for(var linksIndex = 0; linksIndex < this.linkCategories[linkCategoriesIndex].links.length; linksIndex++){
        if(this.linkCategories[linkCategoriesIndex].links[linksIndex].to == window.location.pathname){
          this.subCategorySelected = this.linkCategories[linkCategoriesIndex].links[linksIndex].linkGroup
          this.subCategoryLinkSelected = this.linkCategories[linkCategoriesIndex].links[linksIndex].to
        }
      }
    }
  },
  methods: {
    toggleLinkCategory(mainCategoryIndex) {
      for(var i = 0; i < this.linkCategories.length; i++){
        this.isHoveringSide = true
        if(i == mainCategoryIndex) {
          this.linkCategories[i].visible = true,
          this.linkCategories[i].iconState = "_filled"
        } else {
          this.linkCategories[i].visible = false
          this.linkCategories[i].iconState = "_outlined"
        }
      }
    },
    toggleSubCategory(subCategorySelected) {
      this.subCategorySelected = subCategorySelected
    },
    toggleCollapsed(state) {
      this.collapsed = state
      if(state) {
        this.removeAllVisibility();
      }
      this.$emit('change-collapsed-state', state)
    },
    exitHover() {
      this.isHoveringSide = false
      this.removeAllVisibility();
    },
    removeHover() {
      if(this.isHoveringSide == false) {
        this.removeAllVisibility();
      }
    },
    removeAllVisibility() {
      for(var i = 0; i < this.linkCategories.length; i++){
        this.linkCategories[i].visible = false
      }
    }
  }
}
</script>