<template>
  <div class="confirm-changes">
    <div>
      <span>
        <div>{{ confirmation.confirmationTitle }}</div>
        <div>{{ confirmation.confirmationText }}</div>
      </span>
      <span>
        <button class="outlined" v-on:click="cancel()">{{ confirmation.confirmationCancel.text }}</button>
        <button class="button" v-on:click="save()">{{ confirmation.confirmationAction.text }}</button>
      </span>
    </div>
  </div>
</template>
<script>
module.exports = {
  props: ['confirmation'],
  data() {
    return {
    };
  },
  created() {
  },
  methods: {
    save() {
      console.log('save')
      this.$emit('confirmation-actioned', true)
    },
    cancel() {
      console.log('cancel')
      this.$emit('confirmation-actioned', false)
    }
  }
}
</script>