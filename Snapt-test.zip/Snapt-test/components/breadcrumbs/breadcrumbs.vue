<template>
  <div class="breadcrumbs">
    <div>
      <span>
        {{ crumbs.rootTitle }} <a v-for="(crumb,i) in crumbs.crumbs" :key="i" :href="crumb.link"> <span>/</span> {{ crumb.crumbTitle }} </a>
      </span>
      <div>{{ pageTitle }}</div>
    </div>
  </div>
</template>
<script>
module.exports = {
  props: ['crumbs', 'pageTitle'],
  data() {
    return {
    };
  }
}
</script>