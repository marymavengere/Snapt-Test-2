<template>
    <div :class="selectBoxOptions.formType ? 'select-dropdown-form' : 'select-dropdown'">
        <label v-show="selectBoxOptions.formType">{{ selectBoxOptions.selectLabel }}</label>
        <select @change="onChange($event)">
            <option selected="selected">{{selectBoxOptions.selectTitle}}</option>
            <option v-for="(selectOption,i) in selectBoxOptions.options" :key="i" >{{ selectOption.title }} </option>
        </select >
    </div>
</template>
<script>
module.exports = {
  props: ["options"],
  data: function() {
    return {
        selectBoxOptions: this.options
    };
  },
    methods: {
        onChange(event) {
            var selected = event.target.value
            this.$emit('select-changed', selected)
        }
    }
}
</script>