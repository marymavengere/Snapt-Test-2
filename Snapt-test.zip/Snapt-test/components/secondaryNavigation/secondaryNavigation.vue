<template>
  <div class="secondary-navigation">
      <div>
        <select-dropdown v-on:select-changed="changeAircraft" :options=passSelectOptions></select-dropdown>
      </div>
       <div class="row">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                          <div class="col-lg-12">
                         
                          </div>
                        </div>
                       </div>
                    </div>
                  </div>
  </div>
</template>
<script>
module.exports = {
  props: ['crumbs', 'secondary-nav-items'],
  computed: {
    navActive(){
      if(this.passSelectOptions.selectedOption == 'Select Aircraft') {
        for(var i = 0; i < this.secondaryNavLinks.length; i++) {
          this.secondaryNavLinks[i].active = false
        }
      }
      return this.passSelectOptions.selectedOption != 'Select Aircraft' ? true : false
    }
  },
  data() {
    return {
      passSelectOptions: this.secondaryNavItems.selectOptions,
      secondaryNavLinks: this.secondaryNavItems.links
    };
  },
  methods: {
    toggleSecondaryNavItem(secondaryNaveItemIndex) {
      for(var i = 0; i < this.secondaryNavLinks.length; i++) {
        this.secondaryNavLinks[i].active = false
        if(i == secondaryNaveItemIndex) {
          this.secondaryNavLinks[i].active = true
        }
      }
    },
    changeAircraft(selected) {
      this.passSelectOptions.selectedOption = selected
      this.secondaryNavLinks[0].active = true
    }
  },
  components: {
    'select-dropdown': httpVueLoader('/components/selectDropdown/selectDropdown.vue')
  }
}
</script>